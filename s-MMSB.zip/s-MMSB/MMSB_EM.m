function [] = MMSB_EM(adjMatrix,a,K,labelVec,filename)

% AdjMatrix : NxN
% labelVec  : 1xN
% k : No of Clusters
% alpha : 1 x 1
% betahat  : 1 x k
% eta   : 1 x k
% sigma2 : 1

% initialization
N = size(adjMatrix,1);
alpha = 0.5+(abs(rand(1,K)-0.5)*0.1); % a * ones(1,K);
phi = 1/K * ones(N,N,K);
gammahat = repmat(alpha,N,1)+(rand(N,K)-0.5).*0.1;
dlmwrite('/tmp/gamma.txt',gammahat);
dlmwrite('/tmp/alpha.txt',alpha);
betahat = ones(1,K) - 1e-1;% rand(1,K);
eta = ones(1,K);
labelVec = labelVec ./ max(labelVec);
sigma2 = 0.1;
eps = 0.001;

iter = 1;
conv = false;
oldLL = 0;
while(~conv)
	[gammahat B ll phi inphi] = sMMSB_Estep(adjMatrix, alpha, diag(betahat), gammahat, 5, eta, sigma2, labelVec);
	betahat = diag(B)';
	disp('Finished E-step...');
  [alpha ,eta, sigma2] = sMMSB_Mstep(adjMatrix,labelVec,K,phi,inphi,gammahat,alpha);
	eta
	sigma2
	disp('Finished M-step...');
	newLL = ll;
	str = sprintf('[EM] Iter: %d Loglikelihood: %g',iter,newLL);
	disp(str);
	iter = iter+1;
	gammahat
	betahat
	alpha
	conv = (abs(newLL-oldLL) < eps) || (iter > 50);
	oldLL = newLL;
end

eta
sigma2

% find clusters for each node
[vals clus] = max(gammahat');
pi = load(filename);
[vals trueclus] = max(pi');
resClus = zeros(1,K);
clusStr = {};
for i=1:K
	clusAss = find(trueclus==i);
	%idx1 = unique(clus(clusAss));   count1 = hist(clus(clusAss),idx1);  [v1 id1] = max(count1); idx1(id1)
	fprintf('Cluster assignments %d:\n=====================\n',i);
	disp(clus(clusAss));
  maxClus = mode(clus(clusAss));	numPoints = sum(clus(clusAss)==maxClus);
	if(resClus(maxClus) < numPoints)
		resClus(maxClus) = numPoints;
	end
	clusStr = [clusStr sprintf('clus-%d',i)];
end
fprintf('\n\nAfter assigning to majority, the cluster sizes are:\n');
disp(clusStr);
disp(resClus);
match = sum(resClus);
fprintf('\nNumber of nodes in right groups/clusters: %d\n',match);

end
